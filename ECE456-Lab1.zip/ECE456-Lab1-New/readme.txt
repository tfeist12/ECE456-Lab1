Tyler Feist
Lab #1
ECE 456

This is a symmetric key based encryption / decryption program

Instructions:

Input data to be encrypted/decrypted in data.txt.
Input the key in key.txt. It must be 8 characters long.
These files must be in the same directory as the main script: L1.py.
Navigate to the directory with L1.py in it via the command line
Run the script L1.py by running the command "python L1.py"
The script will read the data and key and output them to you initially.
The data will then be encrypted/decrypted using the key and output to the user